import time
import logging
from typing import Optional
from sqlalchemy.orm import Session
from app.models.chatbot import AIChatbotSetting
from app.repositories.settings_repository import SettingsRepository

logger = logging.getLogger(__name__)

class SettingsCache:
    _instance = None
    _cached_settings = None
    _last_fetch = 0
    _ttl = 300  # 5 minutes

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SettingsCache, cls).__new__(cls)
        return cls._instance

    def get_settings(self, db: Session) -> Optional[AIChatbotSetting]:
        now = time.time()
        if self._cached_settings is None or (now - self._last_fetch) > self._ttl:
            logger.info("Settings cache miss or expired. Fetching from database...")
            try:
                repo = SettingsRepository(db)
                self._cached_settings = repo.get_active_settings()
                self._last_fetch = now
            except Exception as e:
                logger.error(f"Error refreshing settings cache: {e}")
                return self._cached_settings  # Return stale if fetch fails
        return self._cached_settings

    def invalidate(self):
        logger.info("Invalidating settings cache.")
        self._cached_settings = None
        self._last_fetch = 0

settings_cache = SettingsCache()
