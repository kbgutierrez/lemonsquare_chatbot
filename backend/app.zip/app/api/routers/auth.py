"""
User auth verification router.
Thin HTTP layer delegating to user_service.
"""
import logging
from fastapi import APIRouter
from app.services.external.user_service import fetch_user_details
from app.core.exceptions import AuthenticationError, ExternalServiceError

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/auth", tags=["Auth"])


@router.get("/verify", summary="Verify a user token and get details")
async def verify_user(user_token: str):
    try:
        user_data = await fetch_user_details(user_token)
        name = f"{user_data.get('firstname', '')} {user_data.get('lastname', '')}".strip()
        return {
            "valid": True,
            "user_id": user_data.get("id"),
            "company_id": user_data.get("company"),
            "name": name if name else "Unknown User",
        }
    except AuthenticationError as exc:
        return {"valid": False, "error": str(exc)}
    except ExternalServiceError as exc:
        return {"valid": False, "error": str(exc)}
    except Exception as exc:
        logger.error("Unexpected auth error: %s", exc)
        return {"valid": False, "error": "Internal authentication error."}
